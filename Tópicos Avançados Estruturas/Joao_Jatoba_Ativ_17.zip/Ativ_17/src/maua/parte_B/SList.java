package maua.parte_B;

import java.util.List;

public class SList {

    public static void insereInicio(List<Integer> teste,Integer key){
        teste.add(key);
}
}
